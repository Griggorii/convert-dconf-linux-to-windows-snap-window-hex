https://github.com/Griggorii/convert-dconf-linux-to-windows-snap-window-hex

Griggorii setting patent windows 7 fonts ubuntu + color user SPEED

Spawn windows 7 new user name SPEED exit windows to nes session SPEED run user

1) Export color , ubuntu_fonts all

2) Run regedit and registry workshop import reestr 1) griggorii_dconf_setting.reg 2) griggorii_dconf_setting_full.reg

Exit and user re session SPEED resultat
